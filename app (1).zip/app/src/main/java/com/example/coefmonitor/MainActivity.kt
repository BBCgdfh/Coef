package com.example.coefmonitor

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var input: EditText
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(16))
        }

        root.addView(TextView(this).apply {
            text = "Монитор коэффициента"
            textSize = 22f
        })

        root.addView(TextView(this).apply {
            text = "\nУведомить, когда коэффициент станет не меньше:"
            textSize = 16f
        })

        input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(prefs.getString("thr", "2.0"))
        }
        root.addView(input)

        root.addView(Button(this).apply {
            text = "Сохранить порог"
            setOnClickListener {
                val v = input.text.toString().replace(',', '.').toDoubleOrNull()
                if (v == null) {
                    Toast.makeText(this@MainActivity, "Введите число, например 2.5", Toast.LENGTH_SHORT).show()
                } else {
                    prefs.edit().putString("thr", v.toString()).apply()
                    Toast.makeText(this@MainActivity, "Сохранено: $v", Toast.LENGTH_SHORT).show()
                }
            }
        })

        root.addView(Button(this).apply {
            text = "Включить службу (Специальные возможности)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        root.addView(Button(this).apply {
            text = "Тестовое уведомление"
            setOnClickListener { Notifier.send(this@MainActivity, "Тест", "Уведомления работают") }
        })

        status = TextView(this).apply {
            textSize = 15f
            setPadding(0, dp(16), 0, 0)
        }
        root.addView(status)

        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun serviceEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        return s != null && s.contains(packageName)
    }

    private fun refresh() {
        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val time = prefs.getLong("time", 0L)
        val age = if (time == 0L) "ещё не видела Яндекс Про"
        else "${(System.currentTimeMillis() - time) / 1000} сек. назад"
        val seen = prefs.getString("seen", "") ?: ""
        status.text = "Служба: " + (if (serviceEnabled()) "ВКЛЮЧЕНА" else "выключена") +
                "\nПоследняя проверка: $age" +
                "\nПоследнее событие: " + (prefs.getString("evpkg", "нет") ?: "нет") +
                "\nОкна на экране: " + (prefs.getString("winpkgs", "нет") ?: "нет") +
                "\nНайденные числа: " + (if (seen.isEmpty()) "нет" else seen) +
                "\n\nЧто видит служба на экране:\n" + (prefs.getString("dump", "") ?: "")
    }
}
