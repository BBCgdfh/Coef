package com.example.coefmonitor

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.app.Notification

object Notifier {
    private const val CHANNEL = "coef_alert"

    fun send(ctx: Context, title: String, text: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "Коэффициент", NotificationManager.IMPORTANCE_HIGH)
            ch.enableVibration(true)
            ch.vibrationPattern = longArrayOf(0, 400, 200, 400, 200, 400)
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), attrs)
            nm.createNotificationChannel(ch)
        }
        val prefs = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val pkg = prefs.getString("pkg", null)
        val launch = if (pkg != null) ctx.packageManager.getLaunchIntentForPackage(pkg) else null
        val pi = if (launch != null)
            PendingIntent.getActivity(ctx, 0, launch, PendingIntent.FLAG_IMMUTABLE) else null
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(Notification.CATEGORY_ALARM)
            .setAutoCancel(true)
            .apply { if (pi != null) setContentIntent(pi) }
            .build()
        nm.notify(1, n)
    }
}

class MonitorService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var scheduled = false
    private var lastAlerted = -1.0
    private var evCount = 0
    private var evPkg = ""
    private val numRegex = Regex("^\\d{1,2}[.,]\\d{1,2}$")

    override fun onServiceConnected() {
        super.onServiceConnected()
        getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
            .putString("evpkg", "служба запущена, событий ещё не было").apply()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        evCount++
        evPkg = event?.packageName?.toString() ?: "?"
        if (scheduled) return
        scheduled = true
        handler.postDelayed({
            scheduled = false
            scan()
        }, 500)
    }

    override fun onInterrupt() {}

    private fun isTarget(pkg: String) = pkg.contains("yandex") || pkg.contains("taximeter")

    private fun scan() {
        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val roots = ArrayList<AccessibilityNodeInfo>()
        try { rootInActiveWindow?.let { roots.add(it) } } catch (_: Exception) {}
        try { windows.forEach { w -> w.root?.let { roots.add(it) } } } catch (_: Exception) {}

        val pkgs = roots.map { it.packageName?.toString() ?: "?" }.distinct()
        val ed = prefs.edit()
            .putString("evpkg", "$evPkg (событий: $evCount)")
            .putString("winpkgs", if (pkgs.isEmpty()) "нет доступа к окнам" else pkgs.joinToString(", "))

        val values = ArrayList<Double>()
        val texts = ArrayList<String>()
        var found = false
        for (r in roots) {
            val p = r.packageName?.toString() ?: continue
            if (!isTarget(p)) continue
            found = true
            ed.putString("pkg", p)
            walk(r, values, texts, 0)
        }
        if (!found) {
            ed.apply()
            return
        }
        ed.putLong("time", System.currentTimeMillis())
            .putString("dump", texts.joinToString(" | ").take(500))
        if (values.isEmpty()) {
            ed.putString("seen", "").apply()
            return
        }
        ed.putString("seen", values.joinToString("  ")).apply()

        val max = values.max()
        val thr = prefs.getString("thr", "2.0")?.replace(',', '.')?.toDoubleOrNull() ?: 2.0
        if (max >= thr) {
            if (max != lastAlerted) {
                lastAlerted = max
                Notifier.send(this, "Коэффициент $max", "Достиг ${thr}. Откройте Яндекс Про!")
            }
        } else {
            lastAlerted = -1.0
        }
    }

    private fun walk(node: AccessibilityNodeInfo, values: ArrayList<Double>, texts: ArrayList<String>, depth: Int) {
        val t = (node.text ?: node.contentDescription)?.toString()?.trim()
        if (!t.isNullOrEmpty()) {
            texts.add(t)
            if (numRegex.matches(t)) {
                t.replace(',', '.').toDoubleOrNull()?.let { values.add(it) }
            }
        }
        if (depth > 30) return
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            walk(c, values, texts, depth + 1)
        }
    }
}
